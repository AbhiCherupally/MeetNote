<!-- Icon Placeholder - Replace with actual PNG icons -->
<!-- Generate icons at: https://www.favicon-generator.org/ -->

Icons needed:
- icon16.png  (16x16)
- icon48.png  (48x48)
- icon128.png (128x128)

Suggested design:
- Purple/blue gradient background
- White microphone icon
- Modern, minimal style

For now, use any placeholder icons or create simple ones with:
https://www.canva.com/
https://www.figma.com/
https://favicon.io/

Recommended colors:
- Primary: #667eea (Purple)
- Secondary: #764ba2 (Dark Purple)
- Accent: #3b82f6 (Blue)
